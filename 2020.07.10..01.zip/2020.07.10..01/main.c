#include<stdio.h>
int main()
{
    int i,f=1,n;
   Printf(" Input The Number:");
   scanf("%d",&n);
   for (i=1;i<=n;i++)
   f=f*i;
   printf("The Factorial of %d is:%d\n",n,f);
}